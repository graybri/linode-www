#include <stdio.h>
#include <stdlib.h>

#define SCRIPT "\
#!/bin/bash \n\
\n\
#  OPS245 Assignment 1 configuration check\n\
#  Written by: Peter Callaghan\n\
#  Last Modified: 07 Jan '22\n\
#  This script runs a series of commands to determine if you have complete the tasks\n\
#  in assignment 1.  It will create a text file in your home directory called a1.submission.\n\
\n\
if [ $USER != 'root' -a `whoami` != 'root' ]\n\
then\n\
  echo 'You must run this shell script with elevated permissions.' >&2\n\
  exit 1\n\
fi\n\
\n\
userdir=`grep home /etc/passwd | head -1 | cut -d: -f6`\n\
username=`grep home /etc/passwd | head -1 | cut -d: -f1`\n\
cat <<'PPC' > /tmp/ops245.pub\n\
-----BEGIN PGP PUBLIC KEY BLOCK-----\n\
\n\
mQENBGKdHzcBCACv0jy68xczboidRp+JOQ43CJxgX4IxJ/fsQGB9ePTCetdR8eZC\n\
sJYbQGHSeAhnmBuOCgYNOyhzs5CLIj42bU84CdaxMb5ghGsjyhK0gJfFvUY3fTDP\n\
Fj8mmWr6L+pbp2plMKlO0jmU6v9lM+2l86zBG/INFymgFYJzO/7hxA8hSREQyBf6\n\
8Eax9jdtSoR2SeoyUq6Ryn0NlG/rDah+kzzPPWok0kQDwy3IS1GgxW5slqBKRNG8\n\
ArckyszyV5s7JcSoAggj3tQcBeIsTsxJUpHDz1Sybrc65OhGN6QKszJCQkGV/drI\n\
JLsO0Pnq6s58D5N+jXkIlpF2F+U9aMZecbVbABEBAAG0Rk9QUzI0NSBGYWN1bHR5\n\
IChLZXlwYWlyIGZvciBPUFMyNDUgQXNzMSBTMjIpIDxvcHMyNDVAc2VuZWNhY29s\n\
bGVnZS5jYT6JAVQEEwEKAD4WIQR14yTdwmUasLZWGqkyM/4cvqMFZQUCYp0fNwIb\n\
AwUJAJ40AAULCQgHAgYVCgkICwIEFgIDAQIeAQIXgAAKCRAyM/4cvqMFZRynB/9B\n\
LOwFcYjfBRkQWucG2YsvVjfD74+VjPI3K3i6tdDM3j9XcgYqr5T0Ui9tMUR2HL1w\n\
cvNBekjMAfP9XHnBSZr6ETxMN47k/e+c2DYP+eSTgnemQbpUJmQ/pjcIr9/HefhK\n\
J/Op0MNQgAtAyl2VqBDyR7VKoqrJ1o2B0MsCLkJA/H+s8oqxUb6hDbIzLFevlLrL\n\
3h5u5B53qaLa8it7pJMj5fYEK8MztnyojNrZMt864ayYbLar3KgoipLIsFbwvHQ3\n\
XObJ7lOwfZ3BdgB2BERmCgsz77McWnoOh9fYym5Lm6eG2tFvRCqybFhwwpws+gVO\n\
NpJjNcVR4wwLQByzmBtmuQENBGKdHzcBCAC4V8Biv+hY4QN2PqTaHGh9ktGDc0Iw\n\
h1ovod0IFdXMigqGh1c+fKf+uXblBfQRHFcJM1SjjHNlyvG0xZROdMDAOEE2XFBg\n\
/C4/F4ty74Qf+MV3NNMCf8KtSwLTfUKz6v3T7eHkhlIbZnHQq29m5XmaZhcrtmk3\n\
kVnVBSbm2EvVsA2fxAbaBcWdFG9ZD7iahci9Hxe7Nz7QG7JhbpYQ7pM+nTdRwEi1\n\
WU3lliibRlCEfDvMRfnCCRDRZ2tkaykJfQz/EdCVou5zK8It36fuTNrg8bpvaNS/\n\
DP7e2oH55eI3n32VOMXGYCsrY/bpEPdorWHmtd9orHoyRtsLh+Chbr0ZABEBAAGJ\n\
ATwEGAEKACYWIQR14yTdwmUasLZWGqkyM/4cvqMFZQUCYp0fNwIbDAUJAJ40AAAK\n\
CRAyM/4cvqMFZeMRCACJhP/3YR+9Yygx5XWcGVRPBxPw8gR3jmgFFYrJ+Xipsyu9\n\
Qe5Zl5eadiukeGXIp9pLP9tzfV861IzRxs/XGLDOu4c51uwxYNnuTxoc8kb6MNoA\n\
jaClLhIJh19i8i1dHiwwCstUXBpfNfgqpdiOLxfnyRsGw4c/fbrvjxf+OtCGgbi/\n\
PUyaWS6QhZCox4olRNi/tRPRdCdlWDrQCCl3zsHDJJgaPEXK30cI+SCCAzTuozOh\n\
54avibkWtdNrTsT+6+mgPFzf2EY/IHc6yeNH3+O7kBTGhX9RhS+oKEFvTZCbXexW\n\
SzUmg5O/doQ9JtILOuH9Ilkb6wOS28C7/7+dn5If\n\
=5IR2\n\
-----END PGP PUBLIC KEY BLOCK-----\n\
PPC\n\
\n\
cat <<'PPC' > /tmp/checkassign1.bash\n\
#!/bin/bash\n\
echo date: `date`\n\
echo hostname: `hostname` \n\
echo VOLUMES \n\
df -hT \n\
echo SEMULOV \n\
echo '' \n\
echo PASSWD \n\
cat /etc/passwd\n\
echo DWSSAP \n\
echo ''\n\
echo GROUP \n\
cat /etc/group\n\
echo PUORG \n\
echo ''\n\
echo SUDOERS \n\
sed -re '/^[[:space:]]*#/ d' -e '/^[[:space:]]*$/ d' /etc/sudoers \n\
echo SROEDUS \n\
echo '' \n\
echo SUDOERS.D \n\
for file in `find /etc/sudoers.d -type f`\n\
do\n\
  if [ -f $file ]\n\
  then\n\
    echo $file \n\
    cat $file \n\
    echo ''\n\
  fi\n\
done\n\
echo D.SROEDUS \n\
echo '' \n\
echo 'target: ' `systemctl get-default`\n\
echo ''\n\
\n\
echo 'PACKAGES'\n\
yum list installed \n\
echo 'SEGAKCAP'\n\
PPC\n\
\n\
gpg --import /tmp/ops245.pub &> /dev/null\n\
bash /tmp/checkassign1.bash &> $userdir/a1.$username.txt\n\
gpg --encrypt --always-trust --recipient 'OPS245 Faculty' -o $userdir/a1.$username.submit $userdir/a1.$username.txt &> /dev/null\n\
gpg --delete-key --batch --yes 'OPS245 Faculty' &> /dev/null\n\
rm -f /tmp/checkassign1.bash\n\
rm -f /tmp/ops245.pub\n\
\n\
echo 'The script created two files in your home directory.'\n\
echo \"1.  a1.$username.txt - a human-readable copy of the output that you may review.\"\n\
echo \"2.  a1.$username.submit - an encrypted copy of the output to be uploaded to blackboard.\"\n\
echo \"Upload a1.$username.submit to blackboard along with your assignment script.\"\n\
"

int main()
{
	system(SCRIPT);
}
