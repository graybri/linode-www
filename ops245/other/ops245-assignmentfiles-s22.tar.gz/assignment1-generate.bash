#!/bin/bash

# Author: Peter Callaghan
# Edited for Summer 2022 by Brian Gray
# Date: 05 Jun 2022
#
# Purpose: Generate personal instructions for OPS245 assignment 1
#
# USAGE: ./assignment1-generate.bash student-name

username=$1

file=a1.instructions.$1.txt


echo "OPS245 Summer 2022 Assignment 1 instructions for $username" > $file
echo "" >> $file

#Set up arrays of randomizable values
declare -A hosts=([0]=a1 [1]=assign1 [2]=assignment1 [3]=a.1 [4]=assign.1 [5]=assignment.1 [6]=assignmachine [7]=assign.machine [8]=assign1.host [9]=a1.host)
declare -A packagestoadd=([0]=php [1]=emacs [2]=kolourpaint [3]=kiconedit [4]=dragon [5]=subversion)
declare -A packagestoremove=([0]=empathy [1]=brasero [2]=cheese [3]=orca [4]=libyami [5]=liblouis-python [6]=ibus-libpinyin [7]=libburn [8]=libchamplain-gtk [9]=libisofs)

declare -A volumes=([0]=/media [1]=/var [2]=/var/bin [3]=/tmp [4]=/var/sbin [5]=/var/lib [6]=/var/root [7]=/var/lib64 [8]=/var/log [9]=/var/libexec)

declare -A firstname1=([0]=anthony [1]=tony [2]=antoine [3]=antonella [4]=antonio [5]=anne [6]=ann [7]=andy [8]=andrea [9]=andrew)
declare -A lastname1=([0]=clerk [1]=clark [2]=clarker [3]=leclerc [4]=clerkins [5]=karkov [6]=carc [7]=clericus [8]=clarke [9]=leclerck)
declare -A firstname2=([0]=omar [1]=amir [2]=amine [3]=aziz [4]=mehdi [5]=ali [6]=aya [7]=awa [8]=marwa [9]=imane)
declare -A lastname2=([0]=aliyev [1]=jafarov [2]=ahmadov [3]=khatun [4]=rahman [5]=abbasov [6]=perera [7]=fernando [8]=herath [9]=sampath)
declare -A firstname3=([0]=olive [1]=olivia [2]=oliver [3]=mia [4]=mila [5]=milo [6]=miriam [7]=marius [8]=maia [9]=mateo)
declare -A lastname3=([0]=wong [1]=huang [2]=wang [3]=song [4]=sun [5]=lal [6]=ram [7]=raj [8]=singh [9]=singham)

declare -A groups=([0]=admins [1]=administrators [2]=managers [3]="senior_admins" [4]=management [5]=programmers [6]="sen_programmers" [7]="junior_admins" [8]="jun_prog" [9]=subordinates)

declare -A commands=([0]=ip [1]=ss [2]=ps [3]=chmod [4]=vi [5]=cp [6]=mv [7]=yum [8]=gzip [9]=tar)

declare -A scriptcompression=([0]=gzip [1]=bzip2 [2]=xzip)

#Generate random keys to get values from arrays
hostnamekey=$((RANDOM % ${#hosts[@]}))
packageaddkey=$((RANDOM % ${#packagestoadd[@]}))
packageremovalkey=$((RANDOM % ${#packagestoremove[@]}))

mountpointkey=$((RANDOM % ${#volumes[@]}))
volumesizekey=$((RANDOM %10))

fnamekey1=$((RANDOM % ${#firstname1[@]}))
lnamekey1=$((RANDOM % ${#lastname1[@]}))
fnamekey2=$((RANDOM % ${#firstname2[@]}))
lnamekey2=$((RANDOM % ${#lastname2[@]}))
fnamekey3=$((RANDOM % ${#firstname3[@]}))
lnamekey3=$((RANDOM % ${#lastname3[@]}))

groupkey=$((RANDOM % ${#groups[@]}))
gid=$((RANDOM%500 + 2000))

commandkey=$((RANDOM % ${#commands[@]}))

scriptcompressionkey=$((RANDOM % ${#scriptcompression[@]}))

#Use the randomized keys generated above to get values to plug into instructions
hostname="${hosts[$hostnamekey]}"

addpackage="${packagestoadd[$packageaddkey]}"
removepackage="${packagestoremove[$packageremovalkey]}"

customvolume=${volumes[$mountpointkey]}
hundredmegs=$((volumesizekey * 100))
customsize=$((1200 + hundredmegs))

user1="${firstname1[$fnamekey1]} ${lastname1[$lnamekey1]}"
user1short="${firstname1[$fnamekey1]}-${lastname1[$lnamekey1]}"
user2="${firstname2[$fnamekey2]} ${lastname2[$lnamekey2]}"
user2short="${firstname2[$fnamekey2]}-${lastname2[$lnamekey2]}"
user3="${firstname3[$fnamekey3]} ${lastname3[$lnamekey3]}"
user3short="${user3:0:1}-${lastname3[$lnamekey3]}"
group=${groups[$groupkey]}

sudouser=
case $((RANDOM % 3)) in 
	0)	sudouser=$user1
		;;
	1)	sudouser=$user2
		;;
	2)	sudouser=$user3
		;;
esac
sudocommand=${commands[$commandkey]}

scriptcompressiontype=${scriptcompression[$scriptcompressionkey]}

#Write unique instructions for students
echo "Install a new Centos 7 VM into your existing c7host, using any of the installation methods covered in this course." >> $file
echo "Ensure the machine has the gnome-desktop." >> $file
echo "Set the hostname of this machine to be $hostname" >> $file
echo "Provide this VM with 15GiB of storage." >> $file
echo "While the default partition setup will be mostly sufficient, make sure your new VM has a separate $customsize MiB ext4 volume mounted at $customvolume." >> $file
echo "  Note: You can free up space to be able to do this, by shrinking the / volume to 10 GiB." >> $file

echo "Make sure the $addpackage package is present on your machine." >> $file
echo "Make sure the $removepackage package is not present on your machine." >> $file

echo "Create new users called $user1, $user2, and $user3.  Their login names should be $user1short, $user2short, and $user3short respectively." >> $file
echo "Create a group called $group with GID $gid.  Add $user1 and $user3 to it as a supplementary group." >> $file
echo "Set the account for $sudouser so that they can use the sudo command to execute the $sudocommand command (and no others).  Do not use the main sudoers file for this." >> $file

echo "Modify the machine so that it will boot to the command-line automatically." >> $file

echo "" >> $file
echo "Write a python script(on c7host) called vmarchiver.py that will create a complete backup of a single VM the user specifies.  The specific details of how it works are below:" >> $file
echo "  When this script is run, it will present the user with list of the names of all VMs on the current machine (Note: The --name option for the virsh list command will prove helpful for this), and ask the user to enter then name of the VM they would like to archive." >> $file
echo "  If the answer the user provides does not match the name of one of the VMs present on the current machine, the script will display a message to that effect, and prompt the user to enter the name of the VM they would like to archive.  It will keep doing this until the user enters a valid name." >> $file
echo "  Once the user enters the name of a VM, the script will create a tar archive that contains that VM's xml and qcow2 files, compressed using $scriptcompressiontype.  Note, you must obtain the location of the qcow2 image file from the xml file.  Do not just assume it is in /var/lib/libvirt/images, or that it is named after the VM." >> $file
echo "  The archive that is created should be named after the VM and the current date (e.g. vm1-20220131), and should use an extension appropriate to the compression type. " >> $file

#Keep a copy of the random keys used for this student's instructions - Note never to be shared with students
echo "$username - $hostnamekey.$packageaddkey.$packageremovalkey.$mountpointkey.$volumesizekey.$fnamekey1:$lnamekey1.$fnamekey2:$lnamekey2.$fnamekey3:$lnamekey3.$groupkey:$gid.$commandkey.$scriptcompressionkey" >> studentkeys-a1.txt

