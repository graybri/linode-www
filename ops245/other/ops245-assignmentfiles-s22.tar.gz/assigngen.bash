#!/bin/bash

if [ $# -ne 1 ]
then
	echo "Usage: assigngen.bash [assignmentnumber]" >&2
	exit 1
fi

echo "" > studentkeys-a${1}.txt

while read student
do
	name=`echo $student | cut -f3 -d,`
	bash ./assignment${1}-generate.bash $name
done < assignment.csv
#done < assignment-test.csv
