#include <stdio.h>
#include <stdlib.h>

#define SCRIPT "\
#!/bin/bash\n\
\n\
#  OPS245 Assignment 2 configuration check\n\
#  Written by: Peter Callaghan\n\
#  Last Modified: 07 Jan '22\n\
#  This script runs a series of commands to determine if you have completed the tasks\n\
#  in assignment 2.  It will create two text files in your home directory: one for you to read, and an ecrypted one to submit.\n\
\n\
if [ $USER != 'root' -a `whoami` != 'root' ]\n\
then\n\
  echo 'You must run this shell script with elevated permissions.' >&2\n\
  exit 1\n\
fi\n\
\n\
userdir=`grep home /etc/passwd | head -1 | cut -d: -f6`\n\
username=`grep home /etc/passwd | head -1 | cut -d: -f1`\n\
\n\
cat <<'PPC' > /tmp/ops245.pub\n\
-----BEGIN PGP PUBLIC KEY BLOCK-----\n\
\n\
mQENBGHYZKIBCADT0Jngzy6E7RHS1ID/miLymJfySHU1aJfcG4v3C8wJiNvfEQx1\n\
M1hYfm6M0NQb0qfHY8AGfck2sqE+itzx331wFYMb9WrQJmwvqGlh/xMo/Sb4PdRj\n\
1ks/US43vMSWuW/RRtohR5EZYmZGG3uzcMMMGjrtJhqGqAKFRIEwSRjdEmW67YKz\n\
PAwbvmUpOW3PSdrrVlmEZq8012eC7VO3NIZ6/Qb+fWYJDuXVcEGtllzsrCNMD+0P\n\
WZ7kwSJzR7WeDCp5bkIyEO/6XyVbXH+w3zZeVPt2rMK0CReCTPOMH6cMpb66fVdP\n\
DjJDJuZ+qiXLYbI7w/WlFSgDYn+3PEzH+7SdABEBAAG0RU9QUzI0NSBGYWN1bHR5\n\
IChXaW50ZXIgMjAyMiBrZXkgZm9yIE9QUzI0NSkgPG9wczI0NUBzZW5lY2Fjb2xs\n\
ZWdlLmNhPokBVAQTAQgAPhYhBGCQIfXEyN0qLni7A+hcrD0vYK94BQJh2GSiAhsD\n\
BQkAnjQABQsJCAcCBhUKCQgLAgQWAgMBAh4BAheAAAoJEOhcrD0vYK94HZgIANOy\n\
0taYIMUx7Ea/SdUfPhtV327xVZWgbMzWeGQDzxsD8OvUmIXM5RzQvTNGwDjewJn+\n\
KrVStwu6LiTx+HWa83iF0WgIihaQGf5jB1QLB1K0abzlSjSTB7azVVmk9FYNsWLa\n\
ZaJw9QKJpHiG+Xr7FZ2a2HIL5H3sopWlKhaZ7zsSUlTC10AXr0G5QPsuZ19JN2F9\n\
6QJjjczi4GNjxSYhKEp8a+NqsKS9OoMXlxmlK8uUjoXrFeptE2vwhyd2MN1E4F3j\n\
3e1ADmQZG9vvx7bVOcb9w0EbobpZbvmB4e0lscNP72kBwQsqHa0lMIfjnLEXFUEY\n\
+xb65pB84gE+v+kHRLy5AQ0EYdhkogEIAMDnkQLeCPrDYDv6SmHNbsOv7C51M3Ds\n\
wjOwYZeNfKIwN/0+cfBRAxXMryriyTC95XDGYAZVLZQCmHt7t4VSJ4k9pqmZHMzj\n\
gb6lNpPUs/ioldp+UOuRGATr3LuvMn96vT8tHueMXwALpK6HDe3bFJFcqV0rxUYo\n\
txRFOJaqUeqtcxLWzTh3NW8y1UZ9d0jl2OU0NucDVWn9z4Q/Ri5OUDJ11AWcD0Sz\n\
C7/6Ek3rhe4IUH6cuHHfMODxOD8Owf6Rv0id+smDhzFsI8Z2FBNkCki9JB2quVt5\n\
kC9Mm+TztyiEgOrgnz8UQH4ssT3P4o3zta8FRhQ/3+pDtI/Z8NwZsOMAEQEAAYkB\n\
PAQYAQgAJhYhBGCQIfXEyN0qLni7A+hcrD0vYK94BQJh2GSiAhsMBQkAnjQAAAoJ\n\
EOhcrD0vYK94EK8IAKXxsUWlIh/DmZtXFhqpRD2dNRr3GL/3ZgsdtpowYmLex6HR\n\
Q/OSjk8RpL8WaUgu6Dtwp251G16GapvHyIpNT4ettQcvW6/JbMJbFOhYdsgx/JWX\n\
PuZZb7ZW0YXS/FXXGPIknynJa4+kgZUTf2t4y5xe3ZlpDDVK/DhLUB32kW5/mlrj\n\
QGcTN6G6gJP0vxMuZb259uY5qM7qpTXl2zoEOVcbDEuSvwnPhGXHFhRk7+HVBn2F\n\
Az9pbBsSLA6blsOq+AMA176ACezAnPax6lHUbMe6B6nTPmAFPdLv94KjfPl3bRR6\n\
Uo8TM2SE+dJsHYUnDGrmYuJzz4AoTEAVuRGDJ1E=\n\
=Tc1p\n\
-----END PGP PUBLIC KEY BLOCK-----\n\
PPC\n\
\n\
cat <<'PPC' > /tmp/checkassign2.bash\n\
#!/bin/bash\n\
echo date: `date`\n\
echo hostname: `hostname`\n\
echo DISKS\n\
ls -l /dev/[vs]d*\n\
echo SKSID\n\
echo ''\n\
echo VOLUMES\n\
df -hT\n\
echo SEMULOV\n\
echo ''\n\
echo UUIDS\n\
blkid | sed -r 's/^.*UUID=\"([a-zA-Z0-9\\-]+)\".*$/\\1/'\n\
echo SDIUU\n\
echo ''\n\
echo PVS\n\
pvs\n\
echo SVP\n\
echo ''\n\
echo VGS\n\
vgs\n\
echo SGV\n\
echo ''\n\
echo LVS\n\
lvs\n\
echo SVL\n\
echo ''\n\
echo SSM\n\
ssm list\n\
echo MSS\n\
echo ''\n\
echo FSTAB\n\
cat /etc/fstab\n\
echo BATSF\n\
echo ''\n\
echo 'sshd:'`systemctl is-active sshd.service`\n\
echo 'sshd:'`systemctl is-enabled sshd.service`\n\
echo ''\n\
echo SSHD CONFIG\n\
cat /etc/ssh/sshd_config\n\
echo GIFNOC DHSS\n\
echo ''\n\
echo 'AUTHORIZED KEYS'\n\
for account in `ls /home`\n\
do\n\
	echo $account\n\
	if [ -f /home/$account/.ssh/authorized_keys ]\n\
	then\n\
		cat /home/$account/.ssh/authorized_keys\n\
	fi\n\
	echo ''\n\
done\n\
echo SYEK DEZIROHTUA\n\
echo ''\n\
echo HOSTS\n\
cat /etc/hosts\n\
echo STSOH\n\
echo ''\n\
echo INTERFACES\n\
for interface in `ls /etc/sysconfig/network-scripts/ifcfg-*`\n\
do\n\
	echo $interface\n\
	cat $interface\n\
	echo ''\n\
done\n\
echo 'SECAFRETNI'\n\
echo ''\n\
#echo 'firewalld:'`systemctl is-active firewalld.service`\n\
#echo 'firewalld:'`systemctl is-enabled firewalld.service`\n\
#echo ''\n\
#echo 'iptables:'`systemctl is-active iptables.service`\n\
#echo 'iptables:'`systemctl is-enabled iptables.service`\n\
#echo ''\n\
#echo IPTABLES\n\
#iptables -L INPUT -v -n\n\
#echo ''\n\
#iptables -L FORWARD -v -n\n\
#echo SELBATPI\n\
echo ''\n\
echo PASSWD\n\
cat /etc/passwd\n\
echo DWSSAP\n\
echo ''\n\
echo 'target: ' `systemctl get-default`\n\
PPC\n\
\n\
gpg --import /tmp/ops245.pub &> /dev/null\n\
bash /tmp/checkassign2.bash &> $userdir/a2.$username.txt\n\
gpg --encrypt --always-trust --recipient 'OPS245 Faculty' -o $userdir/a2.$username.submit $userdir/a2.$username.txt &> /dev/null\n\
gpg --delete-key --batch --yes 'OPS245 Faculty' &> /dev/null\n\
rm -f /tmp/checkassign2.bash\n\
rm -f /tmp/ops245.pub\n\
\n\
echo 'The script created two files in your home directory.'\n\
echo \"1.  a2.$username.txt - a human-readable copy of the output that you may review.\"\n\
echo \"2.  a2.$username.submit - an encrypted copy of the output to be uploaded to blackboard.\"\n\
echo \"Upload a2.$username.submit to blackboard along with your script.\"\n\
"

int main()
{
	system(SCRIPT);
}
