#!/bin/bash

while read student
do
	user=`echo $student | cut -f3 -d,`
	mail -s "OPS245 Fall 2022 - Assignment 1" \
	 -a a1.instructions.${user}.txt \
	 -c brian.gray@senecacollege.ca \
	 ${user}@myseneca.ca < message1.txt
done < assignment.csv

