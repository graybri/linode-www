#!/bin/bash

# Author: Peter Callaghan
# Date: 20 March 2022
#
# Purpose: Generate personal instructions for OPS245 assignment 2
#
# USAGE: ./assignment2-generate.bash studentname

username=$1

file=assignment2.instructions.$1.txt


echo "OPS245 Winter 2022 Assignment 2 instructions for $username" > $file
	
#Setting up arrays of randomizable values
#Arrays carried over from A1
declare -A hosts=([0]=a1 [1]=assign1 [2]=assignment1 [3]=a.1 [4]=assign.1 [5]=assignment.1 [6]=assignmachine [7]=assign.machine [8]=assign1.host [9]=a1.host)
declare -A firstname1=([0]=anthony [1]=tony [2]=antoine [3]=antonella [4]=antonio [5]=anne [6]=ann [7]=andy [8]=andrea [9]=andrew)
declare -A lastname1=([0]=clerk [1]=clark [2]=clarker [3]=leclerc [4]=clerkins [5]=karkov [6]=carc [7]=clericus [8]=clarke [9]=leclerck)
declare -A firstname2=([0]=omar [1]=amir [2]=amine [3]=aziz [4]=mehdi [5]=ali [6]=aya [7]=awa [8]=marwa [9]=imane)
declare -A lastname2=([0]=aliyev [1]=jafarov [2]=ahmadov [3]=khatun [4]=rahman [5]=abbasov [6]=perera [7]=fernando [8]=herath [9]=sampath)
declare -A firstname3=([0]=olive [1]=olivia [2]=oliver [3]=mia [4]=mila [5]=milo [6]=miriam [7]=marius [8]=maia [9]=mateo)
declare -A lastname3=([0]=wong [1]=huang [2]=wang [3]=song [4]=sun [5]=lal [6]=ram [7]=raj [8]=singh [9]=singham)


#New Arrays for A2
declare -A otherhosts=([0]=remote [1]=distant [2]=neighbour [3]=far [4]=other [5]=elsewhere [6]=somewhereelse [7]=neighbouring [8]=alternate [9]=them)
declare -A networks=([0]=192.168.100 [1]=192.168.30 [2]=192.168.220 [3]=192.168.71 [4]=192.168.47 [5]=192.168.25 [6]=192.168.180 [7]=192.168.97 [8]=192.168.91 [9]=192.168.123)
declare -A monikers=([0]=store [1]=storage [2]=bulkstorage [3]=archives [4]=warehouse [5]=backroom [6]=stockroom [7]=extra [8]=overstock [9]=extrastorage)
declare -A mounts=([0]=store [1]=storage [2]=bulkstorage [3]=archives [4]=warehouse [5]=backroom [6]=stockroom [7]=extra [8]=overstock [9]=extrastorage)
declare -A optionarray=([0]=r [1]=a [2]=j [3]=i [4]=l [5]=o [6]=p [7]=s)
declare -A alternateoptionarray=([0]=q [1]=z [2]=x [3]=c [4]=v [5]=f [6]=n [7]=m)
	

#Retrieve Values from A1 from the student keys file
keystring=`grep $1 studentkeys-a1.txt | cut -d' ' -f3`
hostnamekey=`echo $keystring | cut -d. -f1`

namedata=`echo $keystring | cut -d. -f6-8`
fnamekey1=`echo $namedata | cut -d. -f1 | cut -d: -f1`
lnamekey1=`echo $namedata | cut -d. -f1 | cut -d: -f2`
fnamekey2=`echo $namedata | cut -d. -f2 | cut -d: -f1`
lnamekey2=`echo $namedata | cut -d. -f2 | cut -d: -f2`
fnamekey3=`echo $namedata | cut -d. -f3 | cut -d: -f1`
lnamekey3=`echo $namedata | cut -d. -f3 | cut -d: -f2`

hostname="${hosts[$hostnamekey]}"
user1="${firstname1[$fnamekey1]} ${lastname1[$lnamekey1]}"
user1short="${firstname1[$fnamekey1]}.${lastname1[$lnamekey1]}"
user2="${firstname2[$fnamekey2]} ${lastname2[$lnamekey2]}"
user2short="${firstname2[$fnamekey2]}.${lastname2[$lnamekey2]}"
user3="${firstname3[$fnamekey3]} ${lastname3[$lnamekey3]}"
user3short="${user3:0:1}.${lastname3[$lnamekey3]}"


#Generate random keys to get values from A2 arrays
othermachinekey=$((RANDOM % ${#otherhosts[@]}))
volumegroupkey=$((RANDOM % ${#monikers[@]}))
mountpointkey=$((RANDOM % ${#mounts[@]}))
keyuserkey=$((RANDOM % 3))
optionkey=$((RANDOM % ${#optionarray[@]}))
alternateoptionkey=$((RANDOM % ${#alternateoptionarray[@]}))

#Generate some random values for use directly in variables
thisoctet=$((RANDOM % 8 + 2))
otheroctet=$((RANDOM % 100 + 100))
if [ $thisoctet -eq $otheroctet ]
then
	otheroctet=$((otheroctet + 5))
fi
dnsaddress=$((RANDOM % 10))
size=$((RANDOM % 8 + 5))00
physicalvolumes=$((RANDOM %3 +2 ))

#Use the randomized keys generated above to get values to plug into instructions
#Values for A2
othermachine=${otherhosts[$othermachinekey]}
otheraddress=192.168.245.${otheroctet}/24
machineaddress=192.168.245.${thisoctet}/24
dnsserver=192.168.245.8${dnsaddress}/24
gateway=192.168.245.1/24
vgname=${monikers[$volumegroupkey]}
mountpoint=${mounts[$mountpointkey]}
option=${optionarray[$optionkey]}
alternateoption=${alternateoptionarray[$alternateoptionkey]}
	

keyuser=
case $keyuserkey in 
	0)	keyuser=$user1
		;;
	1)	keyuser=$user2
		;;
	2)	keyuser=$user3
		;;
esac


echo "You may re-use your assignment 1 VM, or install a new Centos 7 VM into your existing c7host, using any of the installation methods covered in this course." >> $file
echo "Make sure that your machine:" >> $file
echo "	1. Has the hostname $hostname." >> $file
echo "	2. Has users called $user1, $user2, and $user3, with login names $user1short, $user2short, and $user3short respectively." >> $file
echo "	3. Boots to the command-line automatically." >> $file
echo "" >> $file
echo "Use the graphical interface for virt-manager on your c7host to provide your virtual machine with an extra 2GiB disk." >> $file
echo "Divide this disk into $physicalvolumes equal parts, which you combine into a volume group called $vgname." >> $file
echo "Use the space provided by $vgname to create a $size MiB ext4 logical volume which you permanently mount at /tmp/$mountpoint." >> $file
echo "" >> $file
echo "Modify the ssh service on this machine to allow only root and $keyuser to login remotely." >> $file
echo "Configure an ssh key to allow you to ssh from your regular user account (the one named after you) on your c7host to $keyuser on this machine without needing a password." >> $file
echo "" >> $file
echo "Configure local hostname resolution so that your machine recognizes the hostname $othermachine as being at $otheraddress" >> $file
echo "" >> $file
echo "Configure this machine's eth0 interface to use the static ip address $machineaddress, with your c7host as the primary DNS server, $dnsserver as the secondary server, and $gateway as the default route." >> $file
echo "" >> $file
echo "Write a python script called hoster-toaster.py that is used to update a machine's local hostname resolution file.  The details of how it works are below:" >> $file
echo "  It requires one argument on the command line:  the absolute path to a file it will read data from.  It will use the information in that file to alter the machine's /etc/hosts file.  If it is run with no other options, it will overwrite the contents of /etc/hosts using the new data in the file provided as the argument." >> $file
echo "  If the script is run with the option -$option it will update the data currently in /etc/hosts with the information in the provided file.  If an ip address in the provided file is not already in /etc/hosts, the entry (and its corresponding hostnames) will be added to /etc/hosts.  If an ip address in the provided file is already in /etc/hosts, the entry already in /etc/hosts will be replaced entirely." >> $file
echo "  If it is run with the option -$alternateoption it will add the data from the provided file to whatever is currently in /etc/hosts.  Note: This option can not be used in the same run of the command as -$option  If an ip address in the provided file is not already in /etc/hosts, the entry (and its corresponding hostnames) will be added to /etc/hosts.  If an ip address in the provided file is already in /etc/hosts, the hostnames listed for it in the provided file will be added to the ones already in /etc/hosts." >> $file
echo "" >> $file
echo "Note that regardless of the options used, the ipv4 and ipv6 localhost addresses /etc/hosts must not be altered." >> $file
echo "Note that if any issues are encountered while accessing either of /etc/hosts or the file provided by the user, your script must handle them gracefully.  Giving an error message and exiting is permissable, crashing is not." >> $file
echo "Note that you must make use of python's file editing capabilities.  Simply re-directing output from a command into the file will not be accepted." >> $file
echo "The format for the provided file will always be:  One address entry per line.  Each line will consist of a valid ipv4 address, a :, and a comma-separated list of hostnames that correspond to that address.  You may assume that the ipv4 addresses in the file are valid." >> $file

echo $username - $hostnamekey.$fnamekey1:$lnamekey1.$fnamekey2:$lnamekey2.$fnamekey3:$lnamekey3.$othermachinekey.$volumegroupkey.$mountpointkey.$keyuserkey.$thisoctet.$otheroctet.$dnsaddress.$size.$physicalvolumes.$option >> studentkeys-a2.txt
