#!/bin/bash

#  OPS245 Assignment 1 group marking script
#  Author: Ahad Mammadov
#  Date: 27 October 2021
#
#  Updated: 5 june 2022 - Brian Gray
#  Updated: 9 sep 2022 - Brian Gray
#       Changed .submit filename pattern
#
#  USAGE: ./marker.bash [assignment_number]
#  Make sure these files are in your pwd:
#	1. marka1.bash (assignment 1 evaluator)
#	2. private.gpg (the key)
#	3. assignment.csv (the class list, the same file that is used to generate the assn instructions)
#	4. submission files (e.g. a1-USERNAME.submit)
#	5. generated assignment instructions (e.g. assignment1-instructions-USERNAME.txt)

if [ $# -ne 1 ]
then
	echo "Usage: marker.bash [assignment_number]" >&2
	exit 1
fi

#imports the key
#gpg --import private.gpg

#decrypts all submissions
for stud in `cut -d, -f3 assignment.csv`
#for stud in `cut -d, -f3 assignment-test.csv`
do
	if test -s A1-submit_$stud_*.submit;then 
		gpg -d A1-submit_$stud_*.submit > a1.$stud.txt 2> /dev/null;fi
done

#marks the submissions
while read student
do
	name=`echo $student | cut -f3 -d,`
	bash ./marka${1}.bash $name
done < assignment.csv
#done < assignment-test.csv
