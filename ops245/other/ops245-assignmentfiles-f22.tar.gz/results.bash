#!/bin/bash

for file in $(ls *result.txt)
	do
		cat $file
		read
	done


