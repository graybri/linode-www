#!/bin/bash

for file in $(ls a2*result.txt)
	do
		cat $file
		read
	done


