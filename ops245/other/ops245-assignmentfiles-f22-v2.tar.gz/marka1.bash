#!/bin/bash

#  OPS245 Assignment 1 marking script
#  Author: Ahad Mammadov
#  Date: 26 Feb 2021
#  Last update: 26 February 2022
#  It checks outputs based on the submission script given below:
#  https://www.dropbox.com/s/tewdere1kg07zxt/checka1?dl=0
#
#  USAGE: ./marka1.bash username
#  Make sure both output and instructions files are in the same 
#  directory along with this marking script

instrfile=a1.instructions.$1.txt
submitfile=a1.$1.txt
resultfile=a1.$1.result.txt

if [ $# -ne 1 ]
then
	echo "Usage: marka1.bash [stud_username]" >&2
	exit 1
fi

#EXISTENCE OF THE INSTRUCTIONS FILE
if test ! -s ${instrfile}; then
	echo "*INSTRUCTIONS FILE* for user '$1' doesn't exist or *WRONG USERNAME!*"
	echo
	exit 2
fi

#EXISTENCE OF THE SUBMISSION FILE
if test ! -s ${submitfile}; then
	echo "*SUBMISSION FILE* for user '$1' doesn't exist or *WRONG USERNAME!*"
	echo
	exit 3
fi

#CHECK IF md5sum HAS CHANGED
#tail -1 ${submitfile} | awk '{print $1}' >> /tmp/$$-from-student.txt
#sed '$d' ${submitfile} | md5sum | awk '{print $1}' >> /tmp/$$-from-output.txt

#LET'S GO
echo "================================================================" > ${resultfile}
echo " OPS245 Fall 2022 Assignment 1 | Evaluation | $1" >> ${resultfile}
echo "================================================================" >> ${resultfile}
deduct=0

#HOSTNAME
ahost=`grep -w "hostname" ${instrfile} | cut -d" " -f9 | sed 's/\.$//'`
ohost=`grep -w "hostname" ${submitfile} | head -1 | cut -d":" -f2| cut -d" " -f2`
if [ "$ahost" != "$ohost" ]
then echo "Wrong hostname (not VM name): '$ohost' - should be '$ahost' [-1]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 1" | bc`;fi

#PARTITION
apart=`grep "ext4" ${instrfile} | cut -d" " -f24 | sed 's/\.$//'`
opart=`sed '/^VOLUMES$/,/^SEMULOV$/ !d' ${submitfile} | sed 's/  */:/g' | cut -d: -f7 | grep -wE "$apart$"`
if [ "$opart" == "" ]
 then echo "Missing custom partition - should be '$apart' [-1]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 1" | bc`
else
 #PARTITION SIZE
 osize=`sed '/^VOLUMES$/,/^SEMULOV$/ !d' ${submitfile} | grep "$opart$" | sed 's/  */:/g' | cut -d: -f3 | sed 's/.$//'`
 sz=`grep -w "MiB" ${instrfile} | cut -d" " -f18`
 asize1=`echo "scale=1; $sz / 1024" | bc`
 asize2=`echo "scale=1; $sz / 1000" | bc`
 if [ "$asize1" != "$osize" -a "$asize2" != "$osize" ]
 then echo "Wrong size: '$osize' - should be '$asize1'G or '$asize2'G [-0.3]" >> ${resultfile}
  deduct=`echo "scale=1; $deduct + 0.3" | bc`;fi

 #PARTITION FS
 ofs=`sed '/^VOLUMES$/,/^SEMULOV$/ !d' ${submitfile} |grep "$opart" | grep -wvE "(/home|/)" | sed 's/  */:/g' | cut -d":" -f2`
 if [ "$ofs" != "ext4" ]
 then echo "Wrong FS: '$ofs' - should be 'ext4' [-0.3]" >> ${resultfile}
  deduct=`echo "scale=1; $deduct + 0.3" | bc`;fi
fi

#INSTALLED PACKAGE
aipack=`grep "is present" ${instrfile} | cut -d" " -f4`
if  [ `sed '/^PACKAGES$/,/^SEGAKCAP$/ !d' ${submitfile} | grep -c "$aipack" ` -lt 1 ]
then echo "The package '$aipack' is not installed [-0.5]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 0.5" | bc`;fi

#REMOVED PACKAGE
#arpack=`grep "not present" ${instrfile} | cut -d" " -f4`
#if  [ `grep -c "$arpack" ${submitfile}` -gt 0 ]
#then echo "The package '$arpack' is not removed [-0.5]" >> ${resultfile}
# deduct=`echo "scale=1; $deduct + 0.5" | bc`;fi
#=======  N O T E  =========
#THIS PART IS DISABLED AS THERE WERE SOME ISSUES FOR REMOVING SOME REQUESTED 
#PACKAGES THAT LED TO REMOVAL OF SOME BASE OR MAJOR PACKAGES

#USER MANAGEMENT
au1fn=`grep -w "users" ${instrfile} | cut -d" " -f5-6 | cut -d"," -f1`
au2fn=`grep -w "users" ${instrfile} | cut -d" " -f7-8 | cut -d"," -f1`
au3fn=`grep -w "users" ${instrfile} | cut -d" " -f10-11 | sed 's/\.$//'`
au1un=`grep -w "users" ${instrfile} | cut -d" " -f18 | cut -d"," -f1`
au2un=`grep -w "users" ${instrfile} | cut -d" " -f19 | cut -d"," -f1`
au3un=`grep -w "users" ${instrfile} | cut -d" " -f21 | cut -d"," -f1`
ou1fn=`sed '/^PASSWD$/,/^DWSSAP$/ !d' ${submitfile} | grep -i "$au1fn" | cut -d: -f5 | tr 'A-Z' 'a-z'`
ou2fn=`sed '/^PASSWD$/,/^DWSSAP$/ !d' ${submitfile} | grep -i "$au2fn" | cut -d: -f5 | tr 'A-Z' 'a-z'`
ou3fn=`sed '/^PASSWD$/,/^DWSSAP$/ !d' ${submitfile} | grep -i "$au3fn" | cut -d: -f5 | tr 'A-Z' 'a-z'`
ou1un=`sed '/^PASSWD$/,/^DWSSAP$/ !d' ${submitfile} | grep "$au1un" | cut -d: -f1`
ou2un=`sed '/^PASSWD$/,/^DWSSAP$/ !d' ${submitfile} | grep "$au2un" | cut -d: -f1`
ou3un=`sed '/^PASSWD$/,/^DWSSAP$/ !d' ${submitfile} | grep "$au3un" | cut -d: -f1`
if [ "$au1fn" != "$ou1fn" ];then 
 echo "Wrong/Missing fullname for user1 - should be '$au1fn' [-0.17]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 0.17" | bc`;fi
if [ "$au2fn" != "$ou2fn" ];then 
 echo "Wrong/Missing fullname for user2 - should be '$au2fn' [-0.17]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 0.17" | bc`;fi
if [ "$au3fn" != "$ou3fn" ];then 
 echo "Wrong/Missing fullname for user3 - should be '$au3fn' [-0.16]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 0.16" | bc`;fi
if [ "$au1un" != "$ou1un" ];then 
 echo "Wrong/Missing username for user1 - should be '$au1un' [-0.17]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 0.17" | bc`;fi
if [ "$au2un" != "$ou2un" ];then 
 echo "Wrong/Missing username for user2 - should be '$au2un' [-0.17]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 0.17" | bc`;fi
if [ "$au3un" != "$ou3un" ];then 
 echo "Wrong/Missing username for user3 - should be '$au3un' [-0.16]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 0.16" | bc`;fi

#GROUP MANAGEMENT
agrnm=`grep -w "group" ${instrfile} | cut -d" " -f5`
agrid=`grep -w "group" ${instrfile} | cut -d" " -f8 | sed 's/\.$//'`
ogrnm=`sed '/^GROUP$/,/^PUORG$/ !d' ${submitfile}| grep "$agrnm" | cut -d: -f1`
ogrid=`sed '/^GROUP$/,/^PUORG$/ !d' ${submitfile}| grep "$agrnm" | cut -d: -f3`
ogru1=`sed '/^GROUP$/,/^PUORG$/ !d' ${submitfile}| grep "$agrnm" | cut -d: -f4 | cut -d, -f1`
ogru2=`sed '/^GROUP$/,/^PUORG$/ !d' ${submitfile}| grep "$agrnm" | cut -d: -f4 | cut -d, -f2`
if [ "$ogrnm" == "" -a  "$ogrid" == "" ]; then
	echo "Missing group '$agrnm' with group id '$agrid' [-1]" >> ${resultfile}
	deduct=`echo "scale=1; $deduct + 0.5" | bc`
else
	if [ "$agrnm" != "$ogrnm" ]
	then echo "Wrong group name: '$ogrnm' - should be '$agrnm' [-0.5]" >> ${resultfile}
	 deduct=`echo "scale=1; $deduct + 0.25" | bc`;fi
	if [ "$ogrid" != "$agrid" ]
	then echo "Wrong group id: '$ogrid' - should be '$agrid' [-0.5]" >> ${resultfile}
	 deduct=`echo "scale=1; $deduct + 0.25" | bc`;fi

	if [ "$ogru1" == "" -a  "$ogru2" == "" ]; then
		echo "Missing group members '$au1un' and '$au3un' [-1]" >> ${resultfile}
		deduct=`echo "scale=1; $deduct + 0.5" | bc`
	else	
		if [ "$ogru1" != "$au1un" -a "$ogru1" != "$au3un" ]
		then echo "Wrong group member: '$ogru1' - should be '$au1un' or '$au3un' [-0.5]" >> ${resultfile}
		 deduct=`echo "scale=1; $deduct + 0.25" | bc`;fi
		if [ "$ogru2" != "$au1un" -a "$ogru2" != "$au3un" ]
		then echo "Wrong group member: '$ogru2' - should be '$au1un' or '$au3un' [-0.5]" >> ${resultfile}
		 deduct=`echo "scale=1; $deduct + 0.25" | bc`;fi
	fi
fi

#SUDOERS
asfn=`grep -w "sudoers" ${instrfile} | cut -d" " -f5-6`
case $asfn in
 $au1fn) asun=$au1un;;
 $au2fn) asun=$au2un;;
 $au3fn) asun=$au3un;;
esac

if [ `sed '/^SUDOERS$/,/^SROEDUS$/ !d' ${submitfile} | sed '/^[[:space:]]*$/ d' | grep -c "$asun"` -ne 0 ]
then echo "Wrong file - the main 'sudoers' file shouldn't be used [-2]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 1" | bc`
else
 if [ `sed '/^SUDOERS.D$/,/^D.SROEDUS$/ !d' ${submitfile} | sed '/^[[:space:]]*$/ d' | wc -l` -le 3 ];then 
  echo "Missing sudoers file - should create a file for '$asun' in /etc/sudoers.d/ directory [-2]" >> ${resultfile}
  deduct=`echo "scale=1; $deduct + 1" | bc`
 else 
  if [ `sed '/^SUDOERS.D$/,/^D.SROEDUS$/ !d' ${submitfile} | sed '/^[[:space:]]*$/ d' | head -2 | tail -1 | cut -d'/' -f4 | grep -c '\.'` -ne 0 ]; then
  echo "Malformed sudoers file name for '$asun' in /etc/sudoers.d/ directory. Sudo ignores names with . in them [-1]" >> ${resultfile}
  deduct=`echo "scale=1; $deduct + 1" | bc`;fi
  
  osun=`sed '/^SUDOERS.D$/,/^D.SROEDUS$/ !d' ${submitfile} | sed '/^[[:space:]]*$/ d' | grep "^$asun" | sed 's/\t/ /g' | cut -d" " -f1`
  if [ "$osun" == "" ];then
   echo "Missing sudoers entry for '$asun' [-1]" >> ${resultfile}
   deduct=`echo "scale=1; $deduct + 1" | bc`;
  else
   osentry=`sed '/^SUDOERS.D$/,/^D.SROEDUS$/ !d' ${submitfile} | sed '/^[[:space:]]*$/ d' | grep "^$asun" | sed 's/[[:space:]]\+/ /g' | cut -d" " -f2 | head -1` 
   if [ "$osentry" != "ALL=(ALL)" -a "$osentry" != "ALL=(root)" -a "$osentry" != "ahost=(ALL)" -a "$osentry" != "ahost=(root)" ];then
    echo "Wrong sudoers entry: '$osentry' - should be ALL=(ALL) [-0.5]" >> ${resultfile}
    deduct=`echo "scale=1; $deduct + 0.5" | bc`;fi
 
   acmd=`grep -w "sudoers" ${instrfile} | cut -d" " -f18`
   ocmd=`sed '/^SUDOERS.D$/,/^D.SROEDUS$/ !d' ${submitfile} | sed '/^[[:space:]]*$/ d' | sed 's/\t/ /g' | grep "^$asun" | cut -d" " -f3 | grep -Ewc "${acmd}m?"` #here m? is for vi/vim cases
   if [ "$ocmd" -eq 0 ];then
    echo "Wrong/Missing command to execute with sudo for user '$asun' - should be '$acmd' [-0.5]" >> ${resultfile}
	deduct=`echo "scale=1; $deduct + 0.5" | bc`;fi
  fi
 fi
fi


#TARGET
ohost=`grep "target:" ${submitfile} | cut -d":" -f2| cut -d" " -f3`
if [ "$ohost" != "multi-user.target" ];then
 echo "Wrong target: '$ohost' - should be set to 'multi-user.target' [-1]" >> ${resultfile}
 deduct=`echo "scale=1; $deduct + 1" | bc`;fi

#RESULTS
if [ "$deduct" == "0" ] 
then echo "*** -=CONGRATULATIONS!=- ***" >> ${resultfile};fi

echo "=================" >> ${resultfile}
deduct=`echo "scale=1; 10 - $deduct" | bc`;echo "  TOTAL: $deduct/10" >> ${resultfile}
echo "=================" >> ${resultfile}
echo "SCRIPT [5 marks]:" >> ${resultfile}

echo "========================================================================="
echo "The evaluation for '$1' is saved in the file '${resultfile}'"
echo "========================================================================="
echo
