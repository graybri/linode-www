#!/bin/bash

for file in $(ls a1*result.txt)
	do
		cat $file
		read
	done


