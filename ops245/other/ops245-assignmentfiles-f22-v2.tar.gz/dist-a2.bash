#!/bin/bash

while read student
do
	user=`echo $student | cut -f3 -d,`
	mail -s "OPS245 Fall 2022 - Assignment 2" \
	 -a a2.instructions.${user}.txt \
	 -c brian.gray@senecacollege.ca \
	 ${user}@myseneca.ca < message2.txt
done < assignment.csv
#done < assignment-test.csv

