#include <stdio.h>
#include <stdlib.h>

#define SCRIPT "\
#!/bin/bash\n\
\n\
#  OPS245 Assignment 2 configuration check\n\
#  Written by: Peter Callaghan\n\
#  Last Modified: 07 Jan '22\n\
#  This script runs a series of commands to determine if you have completed the tasks\n\
#  in assignment 2.  It will create two text files in your home directory: one for you to read, and an ecrypted one to submit.\n\
\n\
if [ $USER != 'root' -a `whoami` != 'root' ]\n\
then\n\
  echo 'You must run this shell script with elevated permissions.' >&2\n\
  exit 1\n\
fi\n\
\n\
userdir=`grep home /etc/passwd | head -1 | cut -d: -f6`\n\
username=`grep home /etc/passwd | head -1 | cut -d: -f1`\n\
\n\
cat <<'PPC' > /tmp/ops245.pub\n\
-----BEGIN PGP PUBLIC KEY BLOCK-----\n\
\n\
mQGNBGNDAhcBDACpLQpBlT6dKn2jsU/ogeig3jXtNHnV1vMOOhHaFPnfroAMbaMH\n\
cgQCXt0R+1GGNrWVK5UpowujCAXLmmUpjeuU7dhUaTa+p1zqfy/JJYvcRq+CHeJm\n\
aEj9kfCaGMuVSG2OCv/hl64sh6sCIwwGABOhA7QRH9HbLYhUPBRbEdjfrBiV4hfb\n\
nhP5xuusnkYMqj+kvg+h3TO5DpbJJeVHI0i/h6+5MmgM3fshVno07qoopF9b4wFr\n\
h7XjcBhYZWYze+isbfDMEsERqqdc6V43VvPKKq3sYHYP0tTPxyo0kHXK3MrN0rN5\n\
r17URp6jtFDNXTPXnqEcod+7fCETgdxJrvdYQTP41U+tOBf2Uz2irRAdSsCQIFPk\n\
GwtapQG7z8VIlATimbLIn3UZ67ymceJaOA7QKe3ogA01FnpAF1u84OV7ThwRd4Ly\n\
sDgVNh37GPRcgzG2ge+9Ga/rHdBVBeEgJTwKv27AdJvAYQ7AU1LkSVcOef4SP9cv\n\
sH2ow4f2UsvLL9MAEQEAAbRAT1BTMjQ1IEZhY3VsdHkgKEZhbGwgMjAyMiBBc3Np\n\
Z25zKSA8YnJpYW4uZ3JheUBzZW5lY2Fjb2xsZWdlLmNhPokB1AQTAQoAPhYhBCUD\n\
deBl8jv9WTi9cVL04aCt3I7FBQJjQwIXAhsDBQkAnjQABQsJCAcCBhUKCQgLAgQW\n\
AgMBAh4BAheAAAoJEFL04aCt3I7FqssL/1Ur8hBsiaaZCNWFjcT2WzvT2B3bnb+V\n\
XhAssDmc405IqfKZ1vk9cfVMPH9hYW5EDAATyPzs0LO0Cx/Jp+q/L50T53bHCL1B\n\
wWZsivpYrX74+ieS0ZbNBcvTUlSQcTb1VDOZnfxy09lPcVz3krBLCfaP1/m0KYtB\n\
tyfMW82Qbvybq69y4p8F6oj1tnnC97hQS9Wroi7K6Q0d68zq2m0WqAcS290sB+5d\n\
mhgKZMEpdiYMGYP/KSjTofcaPMWi3hRNsbs/5pJIiSdm5/HvIPDLtIdWZCT10cfa\n\
0NcXr3hvnrdx5ohkqjXHMAIk+EQPjir+eq64Lu1vVxO3pHUttnSLTQ1Rzu9o6CBM\n\
uQw0bWWEaoxA3SLx0U2CvRi09GHdcjMtAzvEgEfACU63vuss1obr4zT7zTlMCZzV\n\
bLUsrNdwmhynSavUX5hI9WBpdZGt9ZMBoUErXqNLuTyHPnT3HmJYaPS5Anbxo/XV\n\
tFvLmz/3OqOR9v+IfiZR7qRQ/peoyeLobbkBjQRjQwIXAQwAtDpsIapnQhL7aQLc\n\
WwP+5+wYUD/PnOp75tqKOBCc8Bz14LwdAB32uIhemhTBQprKKurfyjPLKigcs7PL\n\
x728hx8aWGEL2VMmU3YeI1sbnOnkcgEWoo93LPuPAnBHkhHA9qk1OhcXbON0Hlv3\n\
UuqzzHunqZYnPPVIXXLiwqIbvdsvle/vvj2Ia+nI5bLh4aAnV/OLSUH9+jgUi+nO\n\
G4N4hSXEVYGxDlFDrA+c7UzC7FKNK0hV01ewkHAX96lM2OhVUL8Ynv9BIhE41DBH\n\
/hPXIU3uTYWMyceJUEU+WFkU8f+BWBJ/DuIduS1vBAbL0FeMiFGp97yPxTVxrwk9\n\
/VCku6uuXEQjxQNekwd7GtUBWi6km28xAKN7LTW8ZDgAWeCbEJpiQB2Evfd9UxBb\n\
tAT+H1/AWQh64VPgbXlfQH9qxd+7cywxw6X17logMKRSALyTUAB6IkzUYjDmunho\n\
8rIW7lgO1gRgrqVmUeGyfj0lB8gKRtCerG34EdGCajII2/YPABEBAAGJAbwEGAEK\n\
ACYWIQQlA3XgZfI7/Vk4vXFS9OGgrdyOxQUCY0MCFwIbDAUJAJ40AAAKCRBS9OGg\n\
rdyOxRN0C/0UzY0miokVMwYa/O/vOVAaSHs/rxTvF1pPpsIyskZT0Sc5zRpz7yBl\n\
nORSfgt7EkKMCRKKK1TyNSfpRAOFkDcwMU3WlhRRkhsQr4xV+kb5PxvMMqJv5Eg5\n\
83fJtjZ8BuwjpqMNqLLipXtpNX3OVzY7yx1rkyP3xcvROlqodJiZXXMiuhx3vLJo\n\
KmIunqnA5pbntGESsyoHCHhr3juEZkUMSbkVzDgvxdeO+DECaaBJnAiTXZyMKNrR\n\
ON5hE7qKOfyfSXNu+VFamXHj3wCN1e/gyJ5D93kR+54E1TEdlS+qbx4RrZg9V0ta\n\
vXEoMA4DlRShdClSfrXGFJ4JjKwofwdtP2fq1f4oF2aS6lHiCisYLGKe9aWZHc3n\n\
B9FWfwKQvvPZ+1gzkQ+9Sm3dCX1/MpOFcd620kyVEIQvK0ZoBbaOWPP3agvT8Y5x\n\
aDC7d3QRrbwbqh715cenyGXUaV0yIRQaV4i+WhyZnB3Zj05NpVCXwxwdOh0DpQeC\n\
FJfRIrVWyZQ=\n\
=8c9L\n\
-----END PGP PUBLIC KEY BLOCK-----\n\
PPC\n\
\n\
cat <<'PPC' > /tmp/checkassign2.bash\n\
#!/bin/bash\n\
echo date: `date`\n\
echo hostname: `hostname`\n\
echo DISKS\n\
ls -l /dev/[vs]d*\n\
echo SKSID\n\
echo ''\n\
echo VOLUMES\n\
df -hT\n\
echo SEMULOV\n\
echo ''\n\
echo UUIDS\n\
blkid | sed -r 's/^.*UUID=\"([a-zA-Z0-9\\-]+)\".*$/\\1/'\n\
echo SDIUU\n\
echo ''\n\
echo PVS\n\
pvs\n\
echo SVP\n\
echo ''\n\
echo VGS\n\
vgs\n\
echo SGV\n\
echo ''\n\
echo LVS\n\
lvs\n\
echo SVL\n\
echo ''\n\
echo SSM\n\
ssm list\n\
echo MSS\n\
echo ''\n\
echo FSTAB\n\
cat /etc/fstab\n\
echo BATSF\n\
echo ''\n\
echo 'sshd:'`systemctl is-active sshd.service`\n\
echo 'sshd:'`systemctl is-enabled sshd.service`\n\
echo ''\n\
echo SSHD CONFIG\n\
cat /etc/ssh/sshd_config\n\
echo GIFNOC DHSS\n\
echo ''\n\
echo 'AUTHORIZED KEYS'\n\
for account in `ls /home`\n\
do\n\
	echo $account\n\
	if [ -f /home/$account/.ssh/authorized_keys ]\n\
	then\n\
		cat /home/$account/.ssh/authorized_keys\n\
	fi\n\
	echo ''\n\
done\n\
echo SYEK DEZIROHTUA\n\
echo ''\n\
echo HOSTS\n\
cat /etc/hosts\n\
echo STSOH\n\
echo ''\n\
echo INTERFACES\n\
for interface in `ls /etc/sysconfig/network-scripts/ifcfg-*`\n\
do\n\
	echo $interface\n\
	cat $interface\n\
	echo ''\n\
done\n\
echo 'SECAFRETNI'\n\
echo ''\n\
#echo 'firewalld:'`systemctl is-active firewalld.service`\n\
#echo 'firewalld:'`systemctl is-enabled firewalld.service`\n\
#echo ''\n\
#echo 'iptables:'`systemctl is-active iptables.service`\n\
#echo 'iptables:'`systemctl is-enabled iptables.service`\n\
#echo ''\n\
#echo IPTABLES\n\
#iptables -L INPUT -v -n\n\
#echo ''\n\
#iptables -L FORWARD -v -n\n\
#echo SELBATPI\n\
echo ''\n\
echo PASSWD\n\
cat /etc/passwd\n\
echo DWSSAP\n\
echo ''\n\
echo 'target: ' `systemctl get-default`\n\
PPC\n\
\n\
gpg --import /tmp/ops245.pub &> /dev/null\n\
bash /tmp/checkassign2.bash &> $userdir/a2.$username.txt\n\
gpg --encrypt --always-trust --recipient 'OPS245 Faculty' -o $userdir/a2.$username.submit $userdir/a2.$username.txt &> /dev/null\n\
gpg --delete-key --batch --yes 'OPS245 Faculty' &> /dev/null\n\
rm -f /tmp/checkassign2.bash\n\
rm -f /tmp/ops245.pub\n\
\n\
echo 'The script created two files in your home directory.'\n\
echo \"1.  a2.$username.txt - a human-readable copy of the output that you may review.\"\n\
echo \"2.  a2.$username.submit - an encrypted copy of the output to be uploaded to blackboard.\"\n\
echo \"Upload a2.$username.submit to blackboard along with your script.\"\n\
"

int main()
{
	system(SCRIPT);
}
